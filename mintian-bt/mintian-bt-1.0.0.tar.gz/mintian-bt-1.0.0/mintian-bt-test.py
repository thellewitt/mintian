#!/usr/bin/env python3
"""
mintian-bt-test - Mintian Broadcom Bluetooth Fix Test

Tests whether a Bluetooth controller is a Broadcom controller via Bluetooth
SIG Manufacturer ID (15), resolves its underlying USB hardware identity,
and checks for active ACL connections for the FC57 priority fix.

Uses:
    - Bluetooth Management interface (controller manufacturer ID)
    - sysfs device tree traversal (USB vendor:product ID resolution)
    - Linux HCIGETCONNLIST ioctl (active connection queries)
    - Raw HCI vendor command FC57
"""

from __future__ import annotations

import argparse
import fcntl
import os
import socket
import struct
import sys

# ------------------------------------------------------------
# HCI Constants & Ioctl Codes
# ------------------------------------------------------------
AF_BLUETOOTH = getattr(socket, "AF_BLUETOOTH", 31)
SOCK_RAW = getattr(socket, "SOCK_RAW", 3)
BTPROTO_HCI = getattr(socket, "BTPROTO_HCI", 1)

HCI_COMMAND_PACKET = 0x01
HCI_CHANNEL_RAW = getattr(socket, "HCI_CHANNEL_RAW", 0)
HCI_CHANNEL_CONTROL = getattr(socket, "HCI_CHANNEL_CONTROL", 3)

HCIGETCONNLIST = 0x800448D4
HCI_CONN_INFO_SIZE = 16

MGMT_OP_READ_INFO = 0x0004
MGMT_EV_CMD_COMPLETE = 0x0001
MGMT_INDEX_NONE = 0xFFFF
MGMT_STATUS_SUCCESS = 0x00

MAX_HCI_CONNECTIONS = 10
VALID_ACL_HANDLE_MAX = 0x0EFF

OGF_VENDOR = 0x3F
OCF_BCM_PRIORITY = 0x57

# Bluetooth SIG Manufacturer ID for Broadcom Corporation
BROADCOM_MANUFACTURER_ID = 15

# ------------------------------------------------------------
# HCI Socket & Command Helpers
# ------------------------------------------------------------
def open_hci_socket(dev_id: int) -> socket.socket:
    """Create and bind a raw HCI socket."""
    sock = socket.socket(
        AF_BLUETOOTH,
        SOCK_RAW,
        BTPROTO_HCI,
    )

    try:
        sock.bind((dev_id, HCI_CHANNEL_RAW))
    except OSError:
        try:
            sock.bind((dev_id,))
        except OSError:
            sock.close()
            raise

    return sock

def get_hci_manufacturer(dev_id: int) -> int | None:
    """
    Return the Bluetooth controller manufacturer ID or None on failure.

    Uses the Linux Bluetooth Management interface
    Read Controller Information command (0x0004).
    """

    request = struct.pack(
        "<HHH",
        MGMT_OP_READ_INFO,
        dev_id,
        0,
    )

    try:
        sock = socket.socket(
            AF_BLUETOOTH,
            SOCK_RAW,
            BTPROTO_HCI,
        )

        with sock:
            sock.bind(
                (
                    MGMT_INDEX_NONE,
                    HCI_CHANNEL_CONTROL,
                )
            )

            sock.settimeout(2.0)
            sock.sendall(request)

            while True:
                response = sock.recv(4096)

                if len(response) < 6:
                    continue

                opcode, index, plen = struct.unpack(
                    "<HHH",
                    response[:6],
                )

                if opcode != MGMT_EV_CMD_COMPLETE:
                    continue

                if index != dev_id:
                    continue

                if plen < 12:
                    return None

                completed_opcode, status = struct.unpack(
                    "<HB",
                    response[6:9],
                )

                if completed_opcode != MGMT_OP_READ_INFO:
                    continue

                if status != MGMT_STATUS_SUCCESS:
                    return None

                return struct.unpack(
                    "<H",
                    response[16:18],
                )[0]

    except OSError:
        return None

    return None

def get_active_handles(dev_id: int) -> list[int] | None:
    """Return active ACL connection handles for the given HCI device."""
    request = (
        struct.pack(
            "<HH",
            dev_id,
            MAX_HCI_CONNECTIONS,
        )
        + b"\x00" * (MAX_HCI_CONNECTIONS * HCI_CONN_INFO_SIZE)
    )

    try:
        with open_hci_socket(dev_id) as sock:
            response = fcntl.ioctl(
                sock.fileno(),
                HCIGETCONNLIST,
                request,
            )
    except OSError:
        return None

    if len(response) < 4:
        return None

    _, count = struct.unpack("<HH", response[:4])
    available = (len(response) - 4) // HCI_CONN_INFO_SIZE
    count = min(count, available, MAX_HCI_CONNECTIONS)

    handles = []

    for i in range(count):
        offset = 4 + (i * HCI_CONN_INFO_SIZE)
        raw = struct.unpack("<H", response[offset:offset + 2])[0]
        handle = raw & 0x0FFF

        if 0 < handle <= VALID_ACL_HANDLE_MAX:
            handles.append(handle)

    return handles


def send_bcm_priority(dev_id: int, handle: int) -> bool:
    """Send the Broadcom FC57 high-priority connection command."""
    if not 0 < handle <= VALID_ACL_HANDLE_MAX:
        return False

    opcode = (OGF_VENDOR << 10) | OCF_BCM_PRIORITY
    params = struct.pack("<BBB", handle & 0xFF, 0x00, 0x01)

    packet = struct.pack(
        "<BHB",
        HCI_COMMAND_PACKET,
        opcode,
        len(params),
    ) + params

    try:
        with open_hci_socket(dev_id) as sock:
            sock.settimeout(2.0)
            sock.sendall(packet)
        return True
    except OSError:
        return False

# ------------------------------------------------------------
# Adapter & USB Identification
# ------------------------------------------------------------
def find_adapters() -> list[str]:
    """Return valid Bluetooth HCI adapter directory paths."""
    adapters = []

    try:
        entries = os.listdir("/sys/class/bluetooth")
    except OSError:
        return adapters

    for entry in sorted(entries):
        if entry.startswith("hci") and entry[3:].isdigit():
            path = os.path.join("/sys/class/bluetooth", entry)
            if os.path.isdir(path):
                adapters.append(path)

    return adapters


def adapter_usb_id(adapter_path: str) -> str | None:
    """
    Traverse sysfs upward to find the USB vendor:product ID.
    """

    device_path = os.path.join(
        adapter_path,
        "device",
    )

    try:
        current = os.path.realpath(device_path)
    except OSError:
        return None

    while current != "/":
        vendor_path = os.path.join(
            current,
            "idVendor",
        )
        product_path = os.path.join(
            current,
            "idProduct",
        )

        try:
            with open(
                vendor_path,
                "r",
                encoding="ascii",
            ) as f:
                vendor = f.read().strip().lower()

            with open(
                product_path,
                "r",
                encoding="ascii",
            ) as f:
                product = f.read().strip().lower()

            if vendor and product:
                return f"{vendor}:{product}"

        except OSError:
            pass

        parent = os.path.dirname(current)

        if parent == current:
            break

        current = parent

    return None

# ------------------------------------------------------------
# Main Routine
# ------------------------------------------------------------
def main() -> int:
    parser = argparse.ArgumentParser(
        description="Test a Bluetooth controller for the Mintian Broadcom FC57 fix."
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Apply FC57 to active ACL connections after confirmation.",
    )
    parser.add_argument(
        "--manufacturer-id",
        action="store_true",
        help="Print only the HCI manufacturer ID and exit.",
    )

    args = parser.parse_args()

    adapters = find_adapters()
    if not adapters:
        print("❌ No Bluetooth adapters found.")
        return 1

    if args.manufacturer_id:
        for adapter in adapters:
            name = os.path.basename(adapter)

            try:
                dev_id = int(name[3:])
            except ValueError:
                continue

            manufacturer = get_hci_manufacturer(dev_id)

            if manufacturer is not None:
                print(manufacturer)
                return 0

        return 1

    print("===================================================")
    print("  Mintian Broadcom Bluetooth Fix Test")
    print("===================================================")
    print()

    if os.geteuid() != 0:
        print("❌ This test must be run as root.")
        print("    Use: sudo ./mintian-bt-test.py")
        return 1

    broadcom_adapters = []

    print("🔍 Bluetooth adapters found:")
    print()

    for adapter in adapters:
        name = os.path.basename(adapter)
        
        try:
            dev_id = int(name[3:])
        except ValueError:
            print(f"    ⚠️ Could not parse device ID from {name}")
            continue

        manufacturer = get_hci_manufacturer(dev_id)
        usb_id = adapter_usb_id(adapter)
        usb_str = f"USB ID {usb_id}" if usb_id else "USB ID unknown"

        # Authoritative test: SIG Manufacturer ID 15 = Broadcom Corporation
        is_broadcom = (manufacturer == BROADCOM_MANUFACTURER_ID)

        if is_broadcom:
            print(
                f"    ✅ {name}: Broadcom "
                f"(HCI Manufacturer {manufacturer}, {usb_str})"
            )
            broadcom_adapters.append((name, dev_id, usb_id))
        elif manufacturer is None:
            print(f"    ⚠️ {name}: Unknown manufacturer ({usb_str})")
        else:
            print(f"    ℹ️  {name}: Non-Broadcom manufacturer {manufacturer} ({usb_str})")

    print()

    if not broadcom_adapters:
        print("❌ No Broadcom Bluetooth controller was detected.")
        print("    The Mintian Broadcom fix does not appear applicable.")
        return 1

    for adapter_name, dev_id, usb_id in broadcom_adapters:
        print(f"🔎 Checking active ACL connections on {adapter_name}...")

        handles = get_active_handles(dev_id)

        if handles is None:
            print("    ❌ Unable to query kernel connection list.")
            continue

        if not handles:
            print("    ⚠️ No active ACL connections found.")
            print("    Connect the Bluetooth device you want to test, then run this test again.")
            continue

        print(f"    ✅ Active ACL connection(s): {', '.join(f'0x{h:04X}' for h in handles)}")
        print()
        print("✅ Controller confirmed Broadcom and active ACL connection is present.")
        print()
        print("    Detected adapter information:")
        print(f"      HCI device: {adapter_name}")
        print(f"      USB ID:     {usb_id if usb_id else 'unknown'}")
        print()

        if not args.apply:
            print("No changes have been made.")
            print()
            print("To apply FC57 for a live test, run:")
            print("  sudo ./mintian-bt-test.py --apply")
            return 0

        print()
        reply = input("Apply the Mintian FC57 priority fix now? [y/N]: ").strip().lower()

        if reply != "y":
            print()
            print("Test cancelled. No changes were made.")
            return 0

        print()
        success = True

        for handle in handles:
            print(f"🚀 Applying FC57 to handle 0x{handle:04X}...")
            if send_bcm_priority(dev_id, handle):
                print(f"    ✅ FC57 applied to 0x{handle:04X}")
            else:
                print(f"    ❌ FC57 failed for 0x{handle:04X}")
                success = False

        print()

        if success:
            print("✅ Mintian FC57 was applied successfully.")
            print()
            print("    Detected adapter information:")
            print(f"      HCI device: {adapter_name}")
            print(f"      USB ID:     {usb_id if usb_id else 'unknown'}")
            print()
            print("Now test the Bluetooth audio device.")
            print("If stuttering disappears, this controller is a strong candidate for the Mintian daemon.")
            return 0

        print("⚠️ One or more FC57 commands failed.")
        return 1

    return 1


if __name__ == "__main__":
    sys.exit(main())
