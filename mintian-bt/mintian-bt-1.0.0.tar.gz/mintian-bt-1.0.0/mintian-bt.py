#!/usr/bin/env python3
"""
mintian-bt - Mintian Broadcom Bluetooth ACL Priority Daemon

Replaces:
    hcitool con
    hcitool cmd
    shell event monitoring

Uses:
    - BlueZ D-Bus connection events
    - Linux HCIGETCONNLIST ioctl
    - Raw HCI vendor command FC57

Broadcom command verified with btmon:
    opcode: 0xFC57
    payload:
        byte 0: ACL handle low byte
        byte 1: reserved
        byte 2: priority high
"""

import os
import sys
import signal
import socket
import struct
import fcntl
import threading
import logging
from dataclasses import dataclass, field

import dbus
from dbus.mainloop.glib import DBusGMainLoop
from gi.repository import GLib

# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------
CONFIG_FILE = "/etc/mintian-bt.conf"

# Default Bluetooth HCI adapter ID
DEFAULT_HCI_DEV = 0

# Raw HCI socket timeout.
# Prevents pathological blocking on socket operations.
HCI_SOCKET_TIMEOUT = 2.0

# Delay before applying FC57 after a connection is detected.
# This allows the kernel connection handle to settle.
FC57_DELAY = 2.0

# ------------------------------------------------------------
# Logging
# ------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] (%(threadName)s) %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)

logger = logging.getLogger("mintian-bt")

# ------------------------------------------------------------
# Configuration Loading
# ------------------------------------------------------------
def load_config() -> int:
    """
    Load the configured HCI adapter number.

    Returns:
        int: HCI adapter number to use.

    A missing configuration file falls back to hci0.
    Invalid configuration is fatal.
    """

    hci_dev = DEFAULT_HCI_DEV

    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as config:
            for raw_line in config:
                line = raw_line.strip()

                if not line or line.startswith("#"):
                    continue

                if "=" not in line:
                    continue

                key, value = line.split("=", 1)
                key = key.strip()
                value = value.strip().strip("'\"")

                if key != "HCI_DEV":
                    continue

                try:
                    hci_dev = int(value)
                except ValueError as exc:
                    raise ValueError(
                        f"Invalid HCI_DEV value in {CONFIG_FILE}: {value!r}"
                    ) from exc

                if not 0 <= hci_dev <= 255:
                    raise ValueError(
                        f"HCI_DEV must be between 0 and 255, got {hci_dev}"
                    )

                break

    except FileNotFoundError:
        logger.warning(
            "Configuration file %s not found; using hci%d",
            CONFIG_FILE,
            DEFAULT_HCI_DEV,
        )

    except OSError as exc:
        raise RuntimeError(
            f"Unable to read {CONFIG_FILE}: {exc}"
        ) from exc

    return hci_dev

# ------------------------------------------------------------
# HCI Constants
# ------------------------------------------------------------
AF_BLUETOOTH = socket.AF_BLUETOOTH
SOCK_RAW = socket.SOCK_RAW
BTPROTO_HCI = getattr(socket, "BTPROTO_HCI", 1)

HCI_COMMAND_PACKET = 0x01
HCI_CHANNEL_RAW = getattr(socket, "HCI_CHANNEL_RAW", 0)

HCIGETCONNLIST = 0x800448D4
HCI_CONN_INFO_SIZE = 16

# HCIGETCONNLIST uses the traditional fixed request size.
MAX_HCI_CONNECTIONS = 10

# ACL connection handles are 12-bit integer values.
VALID_ACL_HANDLE_MAX = 0x0EFF

OGF_VENDOR = 0x3F
OCF_BCM_PRIORITY = 0x57

# ------------------------------------------------------------
# State Management
# ------------------------------------------------------------
@dataclass
class ConnectionState:
    dev_id: int
    handle: int
    cancel_event: threading.Event = field(default_factory=threading.Event)
    patched: bool = False

    def mark_patched(self) -> bool:
        """
        Mark this connection as patched.

        Caller must hold connections_lock.
        Returns True only when the state transition occurs.
        """
        if self.patched:
            return False

        self.patched = True
        return True

connections: dict[tuple[int, int], ConnectionState] = {}
connections_lock = threading.Lock()

stop_event = threading.Event()

# Scan scheduling state.
#
# scan_pending:
#     A delayed GLib scan callback is already scheduled/running.
#
# scan_requested:
#     Another scan was requested while that scan was pending/running.
#
# Keeping these separate prevents a connection event received during
# a scan from being lost.
scan_pending = False
scan_requested = False
scan_lock = threading.Lock()

# ------------------------------------------------------------
# HCI Socket Helper
# ------------------------------------------------------------
def open_hci_socket(
    dev_id: int = DEFAULT_HCI_DEV,
    timeout: float = HCI_SOCKET_TIMEOUT,
) -> socket.socket:
    """
    Create and bind a raw HCI socket for a specific adapter ID.

    The socket is configured with a finite timeout so a pathological
    raw-HCI operation cannot block a worker indefinitely.
    """

    if not isinstance(dev_id, int) or not 0 <= dev_id <= 255:
        raise ValueError(f"Invalid HCI device ID: {dev_id!r}")

    if timeout <= 0:
        raise ValueError(f"Invalid HCI socket timeout: {timeout!r}")

    sock = socket.socket(AF_BLUETOOTH, SOCK_RAW, BTPROTO_HCI)
    sock.settimeout(timeout)

    try:
        sock.bind((dev_id, HCI_CHANNEL_RAW))

    except OSError as e:
        logger.debug(
            "HCI_CHANNEL_RAW bind failed for hci%d (%s); "
            "trying legacy bind",
            dev_id,
            e,
        )

        try:
            sock.bind((dev_id,))

        except OSError as err:
            sock.close()
            raise OSError(
                f"Failed to bind raw HCI socket for hci{dev_id}: {err}"
            ) from err

    return sock

# ------------------------------------------------------------
# Kernel Connection Query
# ------------------------------------------------------------
def get_active_handles(
    dev_id: int = DEFAULT_HCI_DEV,
) -> list[int] | None:
    """
    Return active ACL handles from the kernel HCI connection list.

    Returns:
        list[int]: Active connection handles on success.
        []:       Query succeeded and no connections are active.
        None:     Kernel query failed.
    """

    request = (
        struct.pack(
            "<HH",
            dev_id,
            MAX_HCI_CONNECTIONS,
        )
        + b"\x00" * (
            MAX_HCI_CONNECTIONS * HCI_CONN_INFO_SIZE
        )
    )

    try:
        with open_hci_socket(dev_id) as sock:
            response = fcntl.ioctl(
                sock.fileno(),
                HCIGETCONNLIST,
                request,
            )

    except OSError as e:
        logger.error(
            "HCI connection query failed on hci%d: %s",
            dev_id,
            e,
        )
        return None

    if len(response) < 4:
        logger.error(
            "Invalid HCIGETCONNLIST response on hci%d",
            dev_id,
        )
        return None

    _, count = struct.unpack(
        "<HH",
        response[:4],
    )

    available = (
        len(response) - 4
    ) // HCI_CONN_INFO_SIZE

    count = min(
        count,
        available,
        MAX_HCI_CONNECTIONS,
    )

    handles: list[int] = []

    for i in range(count):
        offset = 4 + (
            i * HCI_CONN_INFO_SIZE
        )

        raw = struct.unpack(
            "<H",
            response[offset:offset + 2],
        )[0]

        handle = raw & 0x0FFF

        if 0 < handle <= VALID_ACL_HANDLE_MAX:
            handles.append(handle)

    return handles

# ------------------------------------------------------------
# Broadcom FC57 Command
# ------------------------------------------------------------
def send_bcm_priority(
    dev_id: int,
    handle: int,
) -> bool:
    """
    Send Broadcom Write High Priority Connection command (FC57).

    Confirmed packet structure:
        01 57 FC 03 HH 00 01
    """

    if not isinstance(handle, int):
        logger.error(
            "Invalid ACL handle type: %r",
            handle,
        )
        return False

    if not 0 < handle <= VALID_ACL_HANDLE_MAX:
        logger.error(
            "Invalid ACL handle 0x%04X "
            "(must be between 0x0001 and 0x%04X)",
            handle,
            VALID_ACL_HANDLE_MAX,
        )
        return False

    if stop_event.is_set():
        return False

    opcode = (
        OGF_VENDOR << 10
    ) | OCF_BCM_PRIORITY

    params = struct.pack(
        "<BBB",
        handle & 0xFF,
        0x00,
        0x01,
    )

    packet = struct.pack(
        "<BHB",
        HCI_COMMAND_PACKET,
        opcode,
        len(params),
    ) + params

    logger.debug(
        "FC57 packet hci%d handle=%04X %s",
        dev_id,
        handle,
        packet.hex(),
    )

    try:
        with open_hci_socket(dev_id) as sock:
            sock.sendall(packet)

        logger.info(
            "🚀 Broadcom priority applied: "
            "hci%d handle=0x%04X (%d)",
            dev_id,
            handle,
            handle,
        )
        return True

    except OSError as e:
        logger.error(
            "FC57 failed hci%d handle=0x%04X: %s",
            dev_id,
            handle,
            e,
        )
        return False

# ------------------------------------------------------------
# Worker Thread
# ------------------------------------------------------------
def delayed_priority_worker(
    dev_id: int,
    handle: int,
    cancel_event: threading.Event,
    delay: float = FC57_DELAY,
) -> None:
    """Wait for the connection to settle, then apply FC57."""

    logger.info(
        "⏳ Scheduled FC57 priority patch for "
        "hci%d handle=0x%04X",
        dev_id,
        handle,
    )

    if cancel_event.wait(delay):
        logger.info(
            "🛑 Cancelled handle 0x%04X",
            handle,
        )
        return

    if stop_event.is_set():
        return

    active_handles = get_active_handles(dev_id)

    # A failed query is not evidence that the connection disappeared.
    if active_handles is None:
        logger.error(
            "Unable to verify handle 0x%04X; "
            "FC57 not sent",
            handle,
        )
        return

    if handle not in active_handles:
        logger.info(
            "⚠️ Handle 0x%04X disappeared",
            handle,
        )
        return

    with connections_lock:
        state = connections.get(
            (dev_id, handle)
        )

        if not state or state.patched:
            return

    if send_bcm_priority(dev_id, handle):
        with connections_lock:
            state = connections.get(
                (dev_id, handle)
            )

            if state:
                state.mark_patched()

# ------------------------------------------------------------
# Disconnect Cleanup
# ------------------------------------------------------------
def cleanup_disconnected_handles(
    dev_id: int = DEFAULT_HCI_DEV,
) -> bool:
    """Remove tracked connections no longer present in the kernel."""

    active_handles = get_active_handles(dev_id)

    # A failed kernel query is not evidence of disconnection.
    if active_handles is None:
        logger.warning(
            "Skipping disconnect cleanup on hci%d; "
            "connection query failed",
            dev_id,
        )
        return False

    active = set(active_handles)

    with connections_lock:
        stale = [
            key
            for key in connections
            if key[0] == dev_id
            and key[1] not in active
        ]

        for key in stale:
            state = connections.pop(key)

            logger.info(
                "🧹 Removed handle 0x%04X on hci%d",
                key[1],
                key[0],
            )

            state.cancel_event.set()

    return False

# ------------------------------------------------------------
# Connection Scanning
# ------------------------------------------------------------
def schedule_new_connections(
    dev_id: int = DEFAULT_HCI_DEV,
) -> bool:
    """
    Find new kernel HCI handles and schedule FC57 patches.
    """

    handles = get_active_handles(dev_id)

    if handles is None:
        return False

    for handle in handles:
        key = (dev_id, handle)

        with connections_lock:
            if key in connections:
                continue

            state = ConnectionState(
                dev_id=dev_id,
                handle=handle,
            )

            connections[key] = state

        threading.Thread(
            target=delayed_priority_worker,
            args=(
                dev_id,
                handle,
                state.cancel_event,
            ),
            daemon=True,
            name=f"Worker-hci{dev_id}-0x{handle:04X}",
        ).start()

    return False

# ------------------------------------------------------------
# Coalesced Scan Request
# ------------------------------------------------------------
def request_coalesced_scan(
    dev_id: int = DEFAULT_HCI_DEV,
) -> None:
    """
    Request a delayed connection scan.

    Multiple connection events received close together are
    coalesced into one scan. If another event arrives while
    the scan is pending or running, one additional scan occurs.
    """

    global scan_pending
    global scan_requested

    with scan_lock:
        if scan_pending:
            scan_requested = True
            return

        scan_pending = True

    def scan_callback() -> bool:
        global scan_pending
        global scan_requested

        schedule_new_connections(dev_id)

        with scan_lock:
            if scan_requested and not stop_event.is_set():
                scan_requested = False
                return True

            scan_pending = False
            scan_requested = False

        return False

    GLib.timeout_add(300, scan_callback)

# ------------------------------------------------------------
# BlueZ Listener
# ------------------------------------------------------------
def bluez_properties_changed(
    *args,
    **kwargs,
) -> None:
    """Handle BlueZ Device1 PropertiesChanged signals."""

    if len(args) < 2:
        return

    interface = args[0]
    changed = args[1]
    path = kwargs.get("path")

    if interface != "org.bluez.Device1":
        return

    if "Connected" not in changed:
        return

    connected = bool(changed["Connected"])
    dev_id = DEFAULT_HCI_DEV

    if not connected:
        logger.info(
            "🔌 Disconnect event detected: %s",
            path,
        )

        GLib.timeout_add(
            100,
            cleanup_disconnected_handles,
            dev_id,
        )
        return

    logger.info(
        "🎧 Connection event detected on D-Bus: %s",
        path,
    )

    request_coalesced_scan(dev_id)

# ------------------------------------------------------------
# Main Execution
# ------------------------------------------------------------
def main() -> None:
    global configured_hci_dev

    if os.geteuid() != 0:
        logger.error("Must run as root")
        sys.exit(1)

    # Load the configuration dynamically.
    try:
        configured_hci_dev = load_config()
    except (RuntimeError, ValueError) as exc:
        logger.error("%s", exc)
        sys.exit(1)

    DBusGMainLoop(set_as_default=True)

    bus = dbus.SystemBus()

    bus.add_signal_receiver(
        bluez_properties_changed,
        signal_name="PropertiesChanged",
        dbus_interface="org.freedesktop.DBus.Properties",
        path_keyword="path",
    )

    loop = GLib.MainLoop()

    def shutdown(
        signum: int,
        frame,
    ) -> None:
        global scan_pending
        global scan_requested

        logger.info("Stopping daemon")

        stop_event.set()

        with scan_lock:
            scan_pending = False
            scan_requested = False

        with connections_lock:
            states = list(
                connections.values()
            )
            connections.clear()

        for state in states:
            state.cancel_event.set()

        GLib.idle_add(loop.quit)

    signal.signal(
        signal.SIGTERM,
        shutdown,
    )
    signal.signal(
        signal.SIGINT,
        shutdown,
    )

    logger.info(
        "🟢 mintian-bt daemon running "
        "(listening on hci%d)",
        configured_hci_dev,
    )

    # Handle connections that already exist before the daemon starts.
    request_coalesced_scan(configured_hci_dev)

    loop.run()

    logger.info("✅ Service stopped cleanly")


if __name__ == "__main__":
    main()
